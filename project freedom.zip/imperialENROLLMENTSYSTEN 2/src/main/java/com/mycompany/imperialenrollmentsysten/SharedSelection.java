/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.imperialenrollmentsysten;

/**
 *
 * @author Admin
 */
public class SharedSelection {

    public static int selectedSubjectId = -1;
    public static String selectedSubjectCode = "";

}
